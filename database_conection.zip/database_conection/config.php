<?php

$servername="localhost";
$username="id19735852_admin";
$password="Radha@8427570203";
$database_name="id19735852_bike_selling_web_project";

$config  = mysqli_connect($servername,$username,$password,$database_name);

if($config ){
    // echo"ok";
 }
else{echo "Failed";}
